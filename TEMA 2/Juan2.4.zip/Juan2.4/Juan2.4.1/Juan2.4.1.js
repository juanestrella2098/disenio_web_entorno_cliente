/*
Declara una función llamada saludo() que muestre una alerta de Bienvenida al visitante al invocar por la consola.
*/

function saludo() {
    alert("Bienvenido");
}