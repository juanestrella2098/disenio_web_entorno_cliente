let rectangulo = {
    ancho: 45,
    alto: 50,
    calcularArea: function () { return this.ancho * this.alto }
}

console.log(rectangulo.calcularArea())